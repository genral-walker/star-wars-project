
const movieActionTypes = {
    'MOVIE_SELECTED': 'MOVIE_SELECTED',
    'MOVIE_FETCHED': 'MOVIE_FETCHED'
};

export default movieActionTypes;